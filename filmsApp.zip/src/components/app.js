import React, { Component } from 'react'
import './app.css'
import axios from 'axios'
import { connect } from 'react-redux'
import { addData, addLikedFilm, addSearch, deleteLikedFilms } from './actions'

const API_KEY = "2c3845db"

class App extends Component {

    dataResult = async (event) => {
        event.preventDefault()
        let searchValue = document.getElementById('search')
        try {
            const response = await axios
                .get(`http://www.omdbapi.com/?apikey=${API_KEY}&s=${searchValue.value}`);

            if (response.data.Response === "False") {
                console.log('GNIDA')
            } else {
                console.log(response);
                
                this.props.onAddData(response.data.Search)
                this.props.onAddSearch(searchValue.value)
            }
            searchValue.value = ''
        } catch (e) {
            console.log(e)
        }
    }

    render() {

        const renderItems = this.props.searchData.map(i => {
            return (
                <li className="flexItems" key={i.imdbID}>
                    <img src={i.Poster} alt="sorry bro" />
                    <span>
                        <p><strong>{i.Title}</strong></p>
                        <p>TYPE: {i.Type}</p>
                        <p>YEAR: {i.Year}</p>
                        <button
                         className="btn btn-danger"
                          id={i.imdbID}
                           onClick={() => this.props.onAddLiked(i.Title)}>On Like</button>
                    </span>
                </li>
            )
        })

        const renderLikedFilms = this.props.onLike.map((i, idx) => {
            return (
                <li key={idx}>
                    <span> {i} </span>
                    <button
                     className="btn btn-dark"
                      id={idx}
                       onClick={() => this.props.deleteLikedFilm(idx)}> delete from list </button>
                </li>
            )
        })

        const renderSearchValues = this.props.search.map(i => {
            return (
                <li key={this.props.search}>
                    <span> {i} </span>
                </li>
            )
        })
        return (
            <div>
                <form className="form" onSubmit={this.dataResult}>
                    <input id="search" className="form-control" />
                    <input type="button"
                        value="search"
                        className="btn btn-primary"
                        onClick={this.dataResult} />
                </form>
                <div className="container" >
                    <div className="films-block">
                        <h2>Result List</h2>
                        <ul>
                            {renderItems}
                        </ul>
                    </div>
                    <div className="like" >
                        <h3>Was liked</h3>
                        <ul id="likedList">
                            {renderLikedFilms}
                        </ul>
                    </div>
                    <div className="search-history" >
                        <h3>Search History</h3>
                        <ul>{renderSearchValues}</ul>
                    </div>
                </div>
            </div>
        )
    }
}
function mapStateToProps(state) {
    return {
        searchData: state.addDataReducer.searchData,
        onLike: state.onLikeReducer.onLike,
        search: state.onSearchReducer.search
    }
}
function mapDispatchToProps(dispatch) {
    return {
        onAddData: dataState => dispatch(addData(dataState)),
        onAddLiked: likeItem => dispatch(addLikedFilm(likeItem)),
        onAddSearch: searchItem => dispatch(addSearch(searchItem)),
        deleteLikedFilm: filmId => dispatch(deleteLikedFilms(filmId))
    }
}

export default connect(mapStateToProps, mapDispatchToProps)(App)


// ЙОУ ЭТО ШКОЛЬНЫЙ РЕП СПЕЦИАЛЬНО ДЛЯ АРТЕМА. ПОСТАВЬ КЛАСС И ПОДПИШИСЬ НА МЕНЯ В ОДНОКЛАССНИКАХ odnoklasniki.ru/GANDON_EBANIY

// Йойойойойо
// Школьный Рэп

// Мы собрались здесь рассказать о
// самой первой любви каждого
// она произошла в 9 лет
// Я толкал её в мужской туалет
// потому что не знал что с девочками делать
// я думал за ними нужно просто бегать
// дергать за косу, бить портфелем
// На спине рисовать белым мелом
// Мне нравилась её милая улыбка
// Я очень ждал каждого звонка
// Она была прекрасна как мегатрон
// потому что у неё были брэкеты ЙОУ КМОН
// Записки в портфель её кидал
// В столовой хлебом в неё бросал
// Когда она меня била, я думал она меня любила
// И мама говорила что бьёт значит любит
// и когда нибудь с тобою будет
// но этого не будет, потому что другого полюбит
// Но я этого совсем не понимал
// И в серьёз её воспринимал

// Припев(2x):
// LONELY (Влюблённый)
// LONELY (Маленький школьниииик)
// LONELY (Сильно влюблённый)
// LONELY (Любит еёёёёёёёоёооёооёоёоо)

// Асфальтоуладчик читает
// О своей любви рассказ начинает
// Дело со мной было в первом классе
// Пошел я в школу в общей массе
// Я увидел рюкзак с любимым героем
// Он был на девочке красивой как море
// Я кинул в неё снежным комком
// она в меня портфелем с человеком пауком
// Так я встретил девочку своей мечты
// Правда я не мечтал тогда о любви
// Я решил с ней подружиться
// Начал рядом с нею крутиться
// Волосы её были волнисты как лапша
// Я решил их сжечь не спеша
// Из за этого меня выгнали из школы
// Теперь я в Лицее, но прописали уколы

// Припев(3x):
// LONELY (Влюблённый)
// LONELY (Маленький школьниииик)
// LONELY (Сильно влюблённый)
// LONELY (Любит еёёёёёёёоёооёооёоёоо)

// Прошло столько лет и мы изменились
// Со школой мы почти простились
// Тех девчёнок мы больше не видали
// Но первый опыт именно от них получали
// Мы конечно сожалеем что так получилось
// Это на наших сердцах отразилось
// И теперь мы нашли свою любовь
// при виде неё в жилах закипиает кровь
// Каждый день я хочу видеть только её
// Моё сердце знает что это моё
// Ты большая загадка для меня
// Но я знаю это не беда
// Только что бы ближе к тебе стать
// Я готов учебный день прогулять
// Мне не нужна никакая работа
// Ведь я люблю тебя...дота

